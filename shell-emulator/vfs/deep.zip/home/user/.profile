export PATH=/bin
